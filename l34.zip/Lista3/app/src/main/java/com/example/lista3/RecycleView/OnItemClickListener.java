package com.example.lista3.RecycleView;

public interface OnItemClickListener  {
    void onItemClick(int position);
}
